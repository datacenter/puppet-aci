export APIC_ADDRESS=https://apic
export APIC_USERNAME=admin
export APIC_PASSWORD=password
export APIC_DN=uni/tn-common
export APIC_ROOT=uni

