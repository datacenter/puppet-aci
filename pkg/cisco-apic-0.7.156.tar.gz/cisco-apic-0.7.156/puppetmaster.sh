puppet master --no-daemonize
