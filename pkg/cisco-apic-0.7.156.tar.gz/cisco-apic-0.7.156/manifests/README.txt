Place the sample puppet manifest site.pp here into ~/.puppet/manifests

Change the nodename at the top to match the name of your controller, and then adjust the parameters to reflect your environment
