puppet device --debug --trace --server localhost --deviceconfig ~/.puppet/device.conf

